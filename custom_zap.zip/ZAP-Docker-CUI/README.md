# ZAP-Docker-CUI

## Using

```
TARGET_URL=http://example.com/ docker compose up
```

