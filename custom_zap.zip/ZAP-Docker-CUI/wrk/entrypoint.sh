#!/bin/bash -ex

date

TARGET_URL=$1
CURRENT_DATE=$(date "+%Y%m%d_%H%M%S")
CONFIG_FILE_PATH=/zap/wrk/zap_$CURRENT_DATE.yaml

echo $TARGET_URL
echo $CURRENT_DATE
echo $CONFIG_FILE_PATH

cp /zap/wrk/zap.dict.yaml $CONFIG_FILE_PATH

# 設定ファイルの書き換え
sed -i -e "s#TARGET_URL#$TARGET_URL#" $CONFIG_FILE_PATH
sed -i -e "s#CURRENT_DATE#$CURRENT_DATE#" $CONFIG_FILE_PATH

# ZAPの実行
zap.sh -cmd -autorun $CONFIG_FILE_PATH

date

echo "RESULT_FILE: result_${CURRENT_DATE}.json"
